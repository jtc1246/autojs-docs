

## Handshake
### C2S
```
{
    "type": "hello",
    "data": {
        
    }
}
```