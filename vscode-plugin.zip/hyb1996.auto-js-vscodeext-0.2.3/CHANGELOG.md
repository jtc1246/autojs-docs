# Change Log
All notable changes to the "auto-js-vscodeext" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

* New Project（新建项目）：选择一个空文件夹（或者在文件管理器中新建一个空文件夹），将会自动创建一个项目
* Run Project（运行项目）：运行一个项目，需要Auto.js 4.0.4Alpha5以上支持
* Save Project（保存项目）：保存一个项目，需要Auto.js 4.0.4Alpha5以上支持