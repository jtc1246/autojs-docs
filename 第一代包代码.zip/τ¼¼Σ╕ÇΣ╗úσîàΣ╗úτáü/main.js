// ================不同设备信息配置================
var all_y = [1680, 1835, 1980, 2140];
var all_x = [60, 170, 275, 381, 485, 592, 698, 807, 911, 1018];
// ==============不同设备信息配置结束================

// ================函数区域=================
var key_x = {
    1: all_x[0],
    2: all_x[1],
    3: all_x[2],
    4: all_x[3],
    5: all_x[4],
    6: all_x[5],
    7: all_x[6],
    8: all_x[7],
    9: all_x[8],
    0: all_x[9],
    Q: all_x[0],
    A: all_x[0],
    W: all_x[1],
    S: all_x[1],
    E: all_x[2],
    D: all_x[2],
    Z: all_x[2],
    R: all_x[3],
    F: all_x[3],
    X: all_x[3],
    T: all_x[4],
    G: all_x[4],
    C: all_x[4],
    Y: all_x[5],
    H: all_x[5],
    V: all_x[5],
    U: all_x[6],
    J: all_x[6],
    B: all_x[6],
    K: all_x[7],
    N: all_x[7],
    L: all_x[8],
    M: all_x[8],
    P: all_x[9]
};
var key_y = {
    1: all_y[0],
    2: all_y[0],
    3: all_y[0],
    4: all_y[0],
    5: all_y[0],
    6: all_y[0],
    7: all_y[0],
    8: all_y[0],
    9: all_y[0],
    0: all_y[0],
    Q: all_y[1],
    W: all_y[1],
    E: all_y[1],
    R: all_y[1],
    T: all_y[1],
    Y: all_y[1],
    U: all_y[1],
    P: all_y[1],
    A: all_y[2],
    S: all_y[2],
    D: all_y[2],
    F: all_y[2],
    G: all_y[2],
    H: all_y[2],
    J: all_y[2],
    K: all_y[2],
    L: all_y[2],
    Z: all_y[3],
    X: all_y[3],
    C: all_y[3],
    V: all_y[3],
    B: all_y[3],
    N: all_y[3],
    M: all_y[3]
};
var allowed_keys = "0123456789QWERTYUPASDFGHJKLZXCVBNM";

var input_key = (key) => {
    press(key_x[key], key_y[key], 50);
};

var input_string = (str) => {
    if (str.length != 5 && str.length != 6) {
        return false;
    }
    var l = str.length;
    for (var i = 0; i < l; i++) {
        var k = str[i];
        if (allowed_keys.indexOf(k) == -1) {
            return false;
        }
        input_key(k);
        sleep(100);
    }
    return true;
}

var x_smallest = (objs) => {
    var l = objs.length;
    var x_min = w + 1;
    var x_min_index = -1;
    for (var i = 0; i < l; i++) {
        var curr = objs[i];
        var this_x = curr.bounds().left;
        if (this_x < x_min) {
            x_min = this_x;
            x_min_index = i;
        }
    }
    return objs[x_min_index];
}

var y_smallest = (objs) => {
    var l = objs.length;
    var y_min = h + 1;
    var y_min_index = -1;
    for (var i = 0; i < l; i++) {
        var curr = objs[i];
        var this_y = curr.bounds().top;
        if (this_y < y_min) {
            y_min = this_y;
            y_min_index = i;
        }
    }
    return objs[y_min_index];
}

var exit_app = () => {
    while (currentPackage() == "com.pingan.genbao") {
        sleep(200);
        back();
    }
}

var allow_capture = () => {
    // 仅适用于小米手机
    sleep(1000);
    text("立即开始").findOne().clickCenter();
}

var up_dayu_bottom = (obj) => {
    var b = obj.bounds();
    return (b.top < b.bottom);
}

var input = () => {
    var a = "";
    rawInput("请输入车牌号", "", (r) => { a = r; })
    return a;
}

var to_array = (istr) => {
    istr = istr.replace(/\r/g, "");
    var arr = istr.split("\n");
    while (arr[arr.length - 1] == "") {
        arr.pop();
    }
    return arr;
}


var tjjg_unselect = () => {
    var tjjg = text("推荐加购").boundsInside(0, 0, w, h - 1).filter(up_dayu_bottom).findOne().bounds();
    var tjjg_btns = boundsInside(0, tjjg.top, w, tjjg.bottom).clickable(true).find();
    var btn = x_smallest(tjjg_btns);
    var img = captureScreen();
    var area = tjjg;
    var up = area.top;
    var down = area.bottom;
    var left = area.left;
    // console.log(up);
    // console.log(down);
    // console.log(left);
    var s = images.findColorEquals(img, "#3b8eff", 0, up, left, down - up);
    // console.log(s);
    sleep(500);
    if (s != null) {
        btn.click();
    }
}


var check_lxdz = () => {
    // 此方法不保证稳定性，目前默认查找到的控件是从上到下排序的，直接使用下标访问并使用setText
    var t = editable(true).find();
    t[t.length - 5].setText("12345678901234")
    t[t.length - 1].setText("12345678901234")
}


// =================函数区域结束================


// =================初始化================
auto();
threads.start(allow_capture);
requestScreenCapture();
// console.show();
sleep(500);
// console.log("start");
console.setPosition(300, 500);
console.setSize(500, 500);
var h = device.height;
var w = device.width;
// 无论初始是否在app界面，均强制退出，保持不在app界面
// launchApp("创保网");
// sleep(10000);
// var a = text("首页").findOne(2000);
// if (a == null) {
//     desc("默认图片描述").id("notice_close_btn").findOnce().clickCenter();
//     sleep(1000);
// }
// exit_app();
var finished = "";
// ===============初始化结束===============


var generate_order = (city, car_plate) => {
    // 生成订单函数
    launchApp("创保网");
    var a = text("首页").findOne(15000);
    if (a == null) {
        desc("默认图片描述").id("notice_close_btn").findOnce().clickCenter();
        sleep(1000);
        a = text("首页").findOnce();
    }
    a.clickCenter();
    sleep(200);
    var chexian = text("车险").findOne();
    if (chexian.bounds().centerY() <= 400) {
        swipe(w * 0.4, h * 0.3, w * 0.4, h * 0.7, 50);
        sleep(4000);
        chexian = text("车险").findOnce();
    }
    chexian.clickCenter();
    sleep(200);
    var lijibaojai = text("立即报价").findOne();
    while (lijibaojai.click() == false) {
        sleep(200);
    }
    sleep(2000);
    editable(true).textContains("鄂").findOne().setText("鄂" + city);
    sleep(1000);
    text("1234A").findOne().clickCenter();
    sleep(1000);
    if (input_string(car_plate) == false) {
        finished = "车牌号格式错误";
        return;
    };
    click(w * 0.5, h * 0.5);
    sleep(200);
    text("立即报价").findOne().click();
    sleep(200);
    text("同意，开始投保").findOne().click();
    sleep(200);
    var qd = text("确定").findOne(15000);
    if (qd == null) {
        finished = "车牌号未查询到";
        return;
    }
    sleep(200);
    if (text("交强险重复投保").findOnce() != null) {
        finished = "交强险重复投保";
        return;
    }
    qd.click();
    sleep(500);
    var syx = text("商业险").findOne().bounds();
    boundsInside(0, syx.top, w, syx.bottom).clickable(true).findOne().click();
    sleep(4000);
    tjjg_unselect();
    sleep(200);
    var sqbj = text("申请报价").findOne();
    sleep(500);
    sqbj.clickCenter();
    sleep(200);
    var qrbj = text("确认报价").findOne(2000);
    if (qrbj == null) {
        qrbj = text("申请报价").findOne();
    }
    sleep(200);
    qrbj.click();
    text("证件有效期限").findOne();
    sleep(1000);
    check_lxdz();
    sleep(1000);
    swipe(w * 0.4, h * 0.7, w * 0.4, h * 0.3, 50);
    sleep(1500);
    var wyyd = text("我已阅读并同意以下需知").findOne().bounds();
    boundsInside(0, wyyd.top, w, wyyd.bottom).clickable(true).findOne().click();
    sleep(200);
    text("确认投保").findOne().click();
    sleep(200);
    text("缓交").findOne().click();
    sleep(2000);
    for (var i = 0; i <= 9; i++) {
        sleep(1000);
        var success = textContains("申请投保完成").findOnce();
        var fail = textContains("投保失败").findOnce();
        if (success != null) {
            // console.log("success");
            finished = "success";
            // console.log(new Date().getTime());
            break;
        }
        if (fail != null) {
            // console.log("fail");
            finished = "投保失败";
            // console.log(new Date().getTime());
            break;
        }
    }
}


var get_phone = (car_plate) => {
    // 在订单生成后获取手机号的函数
    launchApp("创保网");
    var a = text("我的").findOne(10000);
    if (a == null) {
        desc("默认图片描述").id("notice_close_btn").findOnce().clickCenter();
        sleep(1000);
        a = text("我的").findOnce();
    }
    a.clickCenter();
    sleep(2000);
    text("待付款").findOne().clickCenter();
    textContains("可搜索车牌号").findOne();
    sleep(1000);
    while (textContains(car_plate).findOnce() == null) {
        swipe(w * 0.2, h * 0.3, w * 0.2, h * 0.5, 500);
        sleep(1000);
    }
    // console.log("found");
    var loc = textContains(car_plate).findOne().bounds().bottom;
    var dztbd = text("电子投保单").boundsInside(0, loc + 1, w, h).find();
    if (dztbd.length == 0) { finished = "获取手机号失败"; return "获取手机号失败"; }
    y_smallest(dztbd).click();
    sleep(2000);
    var duanxin = text("短信").findOne();
    // console.log(duanxin.bounds());
    sleep(200);
    duanxin.clickCenter();
    sleep(2000);
    var p = id("et_phone").findOne();
    sleep(500);
    var phone_num = p.text();
    // console.log(phone_num);
    sleep(500);
    text("取消").findOne().click();
    sleep(1000);
    swipe(w * 0.2, loc, w * 0.1, loc, 500);
    sleep(1000);
    text("删除").findOne().clickCenter();
    finished = "success";
    return phone_num;
}


var get_phone_for_car = (car) => {
    // 输入格式: 鄂X12345
    var c = car[1];
    var p = car.slice(2);
    finished = "生成订单超时";
    threads.start(() => { generate_order(c, p); });
    var times = 0;
    while (true) {
        sleep(1000);
        times++;
        if (finished != "生成订单超时") {
            break;
        }
        if (times >= 90) {
            threads.shutDownAll();
            break;
        }
    }
    if (finished != "success") {
        exit_app();
        return finished;
    }
    exit_app();
    sleep(2000);
    finished = "查询手机号超时";
    var result = "";
    threads.start(() => { result = get_phone(p); });
    times = 0;
    while (true) {
        sleep(1000);
        times++;
        if (finished != "查询手机号超时") {
            break;
        }
        if (times >= 40) {
            threads.shutDownAll();
            break;
        }
    }
    if (finished != "success") {
        exit_app();
        return finished;
    }
    exit_app();
    return result;
}






var a = input();
var cars = to_array(a);
var len = cars.length;
alert("请确认信息", "共" + len + "个车牌号, 第一个是 " + cars[0] + ", 最后一个是 " + cars[len - 1]);
result_str = "";
var success_num = 0;
for (var i = 0; i < len; i++) {
    var r = get_phone_for_car(cars[i]);
    result_str = result_str + cars[i] + " " + r + "\n";
    files.write("/sdcard/chuangbao.txt", result_str);
    if (r[0] == "1") {
        success_num += 1;
    }
}
setClip(result_str);
alert("运行结束", "成功 " + success_num + " 个, 失败 " + (len - success_num) + " 个。结果已复制到剪贴板, 也可在 chuangbao.txt 文件中查看。");








